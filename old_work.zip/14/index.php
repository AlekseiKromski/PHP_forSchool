<?php
require_once 'functions.php';
?>
<html>
    <head>
        <title>Выполнение заданий</title>
        <link rel="stylesheet" href="css/style.css" type="text/css"/>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>
    <body>
        <?php
            
        ?>
        <form method="post">
            <p>
                A: 
                <input type="text" name="A">
                <input type="text" name="A2">
            </p>
            <p>
                B: 
                <input type="text" name="B">
                <input type="text" name="B2">
            </p>
            <p>
                C: 
                <input type="text" name="C">
                <input type="text" name="C2">
            </p>
            <p>
                D: 
                <input type="text" name="D">
                <input type="text" name="D2">
            </p>
            <p>
                <input type="submit" value="Отправить">
            </p>
        </form>
    </body>
</html>

