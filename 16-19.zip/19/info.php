<?php
	$product = [
		'iphone' => [
			'desc' => 'he iPhone has a sleek, minimalist design, and differs from other smartphones in its lack of buttons. Most operations on the iPhone are performed using the touch screen display.',
			'price' => 1200,
			'img' => 'iphone.png'
		],
		'samsung' => [
			'desc' => 'Samsung, South Korean company that is one of the worlds largest producers of electronic devices. Samsung specializes in the production of a wide variety of consumer and industry electronics, including appliances',
			'price' => 899,
			'img' => 'samsung.jpg'
		],
		'xiaomi' => [
			'desc' => 'Xiaomi Corporation is a Chinese electronics company founded by Lei Jun in 2010 and headquartered in Beijing. Xiaomi makes and invests in smartphones',
			'price' => 120,
			'img' => 'xiaomi.jpg'
		],
	];


?>